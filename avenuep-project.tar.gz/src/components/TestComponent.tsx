export default function TestComponent() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold">ทดสอบ</h1>
      <p>หน้านี้ทำงานได้</p>
    </div>
  )
}